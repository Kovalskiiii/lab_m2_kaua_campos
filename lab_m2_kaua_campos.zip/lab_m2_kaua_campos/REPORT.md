# REPORT — Processamento de Imagens 2026-02 · M2.1 e M2.2

Aluno: Kauã Kovalski de Campos · Linguagem: C++17 · OpenCV 4.6.0 · Comandos e opções: ver `README.md`.
Todos os números abaixo saem de `./run_all.sh` (tabelas em `results/*.csv`, resumos em `results/*_summary.json`).

---

# Seção M2.1 — Máscara binária e segmentação

## 1. Alvo e imagens

**Alvo:** discos de cor laranja (objeto de interesse) sobre fundo azul-escuro. Pontos laranja minúsculos
(poeira/ruído) **não** são objetos de interesse. Para tornar o "número real de objetos" conhecido, as duas imagens de
entrada são **sintéticas**, geradas por `tools/make_images.py` (semente fixa, 640×480); os arquivos de `images/input/`
não foram alterados por nenhuma etapa.

| imagem | descrição | número real de discos (por construção) |
|---|---|---|
| `cena_favoravel` | fundo uniforme, ruído gaussiano leve (σ=3), 6 discos separados e 1 ponto isolado de raio 3 px | 6 |
| `cena_dificil` | gradiente de iluminação (×0,45 na esquerda → ×1,9 na direita, com saturação de canais na direita), sombras, ruído σ=6, **dois discos em contato**, um disco com **furo** pequeno, um disco **cortado pela borda**, 14 partículas pequenas | 6 (o par conta como 2) |

Como as imagens são sintéticas, **não** substituem fotos reais; as conclusões valem para esse tipo de cena.

## 2. Configurações (mesmas imagens, mesmos parâmetros por configuração)

| config | método | parâmetros | pré-processamento |
|---|---|---|---|
| `fixed` | limiar fixo em cinza | `--threshold 120` (cinza > 120 ⇒ objeto) | nenhum |
| `otsu` | Otsu global | limiar calculado: 97 (`cena_favoravel`), 111 (`cena_dificil`) | Gaussiana 5×5 |
| `adaptive` | adaptativo (média Gaussiana) | `--block-size 101 --c -10` | Gaussiana 5×5 |
| `hsv` | intervalo HSV (escala OpenCV) | H 5–40, S 100–255, V 40–255 | Gaussiana 5×5 |

O objeto é claro e saturado, então nenhuma inversão foi usada. A Gaussiana 5×5 foi aplicada em `otsu`, `adaptive` e
`hsv` para reduzir o ruído de pixel antes do limiar; `fixed` ficou **sem** pré-processamento de propósito (é a linha de
base, e a comparação `fixed` × `hsv` mistura portanto método e pré-processamento — ver limitação no fim da seção).
O adaptativo com `C = 5` (valor positivo) marcou ~79–82% da imagem como objeto (fundo uniforme passa no teste
`pixel > média − C`); por isso `C = −10`.

## 3. Proporção de primeiro plano

| imagem | fixed | otsu | adaptive | **hsv** |
|---|---|---|---|---|
| `cena_favoravel` | 0,1661 | 0,1669 | 0,1209 | **0,1716** |
| `cena_dificil` | 0,1277 | 0,1400 | 0,1075 | **0,1553** |

(proporção = pixels 255 / pixels totais; contagens absolutas em `results/m2_1_proportions.csv`.) Não há máscara de
referência exportada, portanto **não se declaram acurácia, precisão ou revocação**: os erros abaixo são observações
visuais nas figuras, e as proporções apenas permitem comparar configurações entre si.

## 4. Figuras

Linha 1: original, `fixed`, `otsu`, `adaptive`; linha 2: `hsv`, sobreposição de `fixed`, sobreposição de `hsv`
(vermelho translúcido = máscara, verde = contorno).

![cena_favoravel](results/figures/fig_m2_1_cena_favoravel.png)
*Figura 1 — `cena_favoravel`: `fixed`, `otsu` e `hsv` produzem máscaras visualmente equivalentes; `adaptive` gera anéis.*

![cena_dificil](results/figures/fig_m2_1_cena_dificil.png)
*Figura 2 — `cena_dificil`: `fixed` e `otsu` perdem o interior dos discos na região escura (esquerda); `hsv` recupera os 6 discos.*

## 5. Configuração de trabalho para o M2.2

**Escolhida: `hsv` (H 5–40, S 100–255, V 40–255, Gaussiana 5×5), arquivos `images/output/<imagem>_mask.png`.**

- **Acertos (visuais):** em `cena_dificil`, todos os 6 discos aparecem preenchidos, inclusive o da esquerda, escuro, e o
  da direita, saturado em amarelo; o contorno verde da sobreposição acompanha a borda dos discos; a sombra projetada
  não entra na máscara (matiz azulado, fora do intervalo).
- **Falsos negativos visíveis:** o furo pequeno de um disco (à direita) continua preto; o disco da borda direita está
  cortado pela própria imagem (esperado). Em `fixed`, os dois discos da esquerda saem pela metade, com borda esparsa
  (ruído); em `otsu` (limiar 111) o disco de cima sai cortado em meia-lua (Fig. 2).
- **Falsos positivos visíveis:** partículas laranja pequenas (13 componentes pequenos em `cena_dificil`, 1 em `cena_favoravel`) entram na
  máscara — são o alvo da morfologia do M2.2. O par de discos em contato vira uma região única (não é erro de
  limiar; é contato real).
- **Por que HSV e não `fixed`:** o matiz/saturação do objeto são estáveis sob o gradiente de iluminação; o cinza
  não (no disco do canto superior esquerdo o cinza médio é ≈ 115, entre 87 e 143, cruzando o limiar 120). Em
  `cena_favoravel`, `fixed` funcionaria igualmente.

## 6. Validação das saídas

O programa confere antes de gravar (e os testes automáticos repetem): mesma largura/altura da entrada, 1 canal,
conjunto de valores exatamente {0, 255}, PNG sem perdas (saída `.jpg` é rejeitada com erro). A contagem de pixels de
primeiro plano e a proporção ficam em `<máscara>.json` e na saída padrão.

## 7. Discussão

**(a) Quando o limiar fixo falhou ou funcionou.** Funcionou em `cena_favoravel`: fundo (cinza médio ≈ 33) e objeto
(≈ 161) estão bem separados, e variar o limiar de 60 a 150 muda a proporção só de 0,1684 para 0,1639. Falhou em
`cena_dificil`, onde o gradiente de iluminação faz o cinza do mesmo tipo de objeto variar com a posição (disco do canto
superior esquerdo: média ≈ 115, de 87 a 143), de modo que metade dele fica abaixo de 120: a máscara sai pela
metade e esparsa. Otsu global (limiar 111) herda a mesma limitação por ser global. O adaptativo
não resolveu: com blocos de 101 px, o interior de um disco de ~100 px é uniforme e passa a ser comparado com a própria
média, resultando em anéis (Fig. 1 e 2), isto é, o tamanho de bloco precisaria ser bem maior que o objeto.

**(b) Parâmetro mais sensível.** No limiar fixo, em `cena_dificil` a proporção cai de 0,2004 (T=60: o fundo à direita, cinza ≈ 61, vaza) para 0,0879 (T=180), passando por 0,1522 / 0,1277 / 0,0991 em T = 90 / 120 / 150; em `cena_favoravel` é
quase constante até T=150 e vai a **0** em T=180 (o objeto tem cinza ≈ 161). No HSV, o matiz máximo foi o mais
sensível: com H máx. = 20 / 25 / 30 / 35 a proporção em `cena_dificil` é 0,0923 / 0,1085 / 0,1543 / 0,1553 (os discos
saturados da direita ficam amarelados e saem da faixa se H máx. for baixo), enquanto `cena_favoravel` não muda
(0,1716 para todos). (`results/m2_1_sensitivity_*.csv`.)

**(c) Erros que atrapalham a contagem no M2.2.** (i) *Fragmentação:* a máscara `fixed` de `cena_dificil` tem 365
componentes em conectividade 4 e 186 em 8, contra 6 objetos reais (ruído esparso do disco escuro); com Otsu são 28/25,
adaptive 25/22 e hsv 18/18 (`results/m2_1_components_by_config.csv`). (ii) *Partículas:* contam como objetos se
não forem removidas. (iii) *Contato:* o par de discos é um só componente em qualquer configuração. (iv) *Furo:* não
altera a contagem, mas altera área e centroide. (v) *Objeto na borda:* conta como um componente, com área parcial.

**Limitações.** Imagens sintéticas, com objeto de formato e cor simples; `fixed` sem blur versus os outros com blur
confunde dois efeitos (um teste de `fixed` com blur 5 não foi feito); as proporções não são métricas de qualidade.

---

# Seção M2.2 — Componentes conexos e sequência morfológica

## 1. Ponto de partida

Máscaras de trabalho do M2.1 (`images/output/cena_favoravel_mask.png`, `images/output/cena_dificil_mask.png`; objeto
= 255, fundo = 0). O `analyze` guarda cópia fiel em `results/<imagem>_mask_initial.png`. Comandos em `README.md`.
Análise final: **conectividade 8**, `--min-area 20` (componente mantido se área ≥ 20 px; o rótulo de fundo nunca
é contado). O filtro de área é aplicado igualmente às contagens inicial e final.

## 2. Rotulação 4 × 8 na mesma máscara inicial (mesmo `--min-area 20`)

| imagem | bruto (4) | bruto (8) | filtrado (4) | filtrado (8) |
|---|---|---|---|---|
| `cena_favoravel` | 7 | 7 | 7 | 7 |
| `cena_dificil` | 18 | 18 | 15 | 15 |

Nas máscaras HSV não há componentes ligados apenas por diagonal, então 4 e 8 coincidem (e coincidem também na
máscara final: 6/6 e 5/5). A diferença aparece quando há pixels diagonais: o teste automático com dois pixels na
diagonal dá 2 componentes em conectividade 4 e 1 em 8; na máscara `fixed` de `cena_dificil` (ruído esparso) são 365
(4) contra 186 (8) componentes brutos. Conectividade 8 foi escolhida para a análise final porque une pixels que
tocam apenas pela diagonal em bordas de objetos redondos digitalizados, evitando fragmentar um objeto contínuo; o
custo é poder unir objetos que se tocam só num canto.

CSVs: `results/cena_favoravel_initial.csv`, `results/cena_dificil_initial.csv` (e `_final.csv`), com
`label,area,x,y,width,height,cx,cy,kept`.

## 3. Sequência morfológica

Elementos estruturantes **elípticos** (aproximam o formato circular dos objetos), 1 iteração cada, arquivo
`morph_sequence.txt`:

| # | operação | elemento | problema visado | arquivo |
|---|---|---|---|---|
| 1 | abertura | elipse 9×9 | partículas isoladas (até ~9 px de largura na máscara, já com o blur do M2.1); a abertura remove o que não comporta um elemento 9×9 | `results/<img>_stage1_open.png` |
| 2 | fechamento | elipse 11×11 | furo de ~7 px dentro de um disco e reentrâncias de contorno | `results/<img>_stage2_close.png` |

**Ordem:** a abertura vem primeiro porque um fechamento antes poderia unir partículas vizinhas em manchas maiores
que a abertura já não removeria (hipótese). Numa exploração com elementos 5 e 9, abertura→fechamento e
fechamento→abertura deram o mesmo número de componentes em `cena_dificil` (14 brutos, 11 após filtro), então a ordem
foi adotada por esse argumento, não por uma diferença medida. **Tamanho:** a abertura precisa comportar mais que a maior
partícula (~9 px na máscara). Na exploração em `cena_dificil` (abertura + fechamento 9, 5 regiões de disco): abertura
5×5 deixou 14 componentes brutos (11 após filtro), 7×7 deixou 9, e 9×9 deixou só as 5 regiões de disco. Essas
explorações **não** estão no `run_all.sh`; apenas a variante com elementos 3/5 está em `results/variants/`.

![sequência cena_dificil](results/figures/fig_m2_2_cena_dificil.png)
*Figura 3 — `cena_dificil`: máscara inicial rotulada (18 componentes), abertura, fechamento e rótulos finais (5).*

![sequência cena_favoravel](results/figures/fig_m2_2_cena_favoravel.png)
*Figura 4 — `cena_favoravel`: 7 → 6 componentes; o ponto isolado é removido pela abertura.*

## 4. Antes × depois (conectividade 8, `--min-area 20`)

| imagem | etapa | componentes brutos | componentes após filtro | área total de 1º plano (px) |
|---|---|---|---|---|
| `cena_favoravel` | inicial | 7 | 7 | 52 710 |
| `cena_favoravel` | final | 6 | 6 | 52 651 (−59) |
| `cena_dificil` | inicial | 18 | 15 | 47 696 (mantida: 47 673) |
| `cena_dificil` | final | 5 | 5 | 47 399 (−297) |

Observações:

1. `cena_dificil`: o filtro de área sozinho (≥ 20 px) deixa 15 componentes (5 regiões de disco + 10 partículas),
   porque várias partículas têm 21–48 px; abertura + fechamento leva a 5 (os 13 componentes pequenos desaparecem).
2. `cena_favoravel`: 7 → 6; o componente removido é o ponto de 57 px (caixa 9×9), e os seis discos mudam no máximo
   1 px de área (ex.: 7650 → 7649).
3. O fechamento alterou contornos: na máscara `cena_dificil`, a área do disco com furo passou de 9 904 para 9 917 px
   e a do par em contato de 15 831 para 15 862 px (reentrância entre os dois discos preenchida; furo de ~7 px
   fechado).
4. A soma das áreas dos componentes brutos é igual ao total de pixels de primeiro plano da respectiva máscara, antes
   do filtro (`area_sum_check` = `true` nos resumos; também testado).

Arquivos: `results/<img>_labels.png` (rótulos e caixas finais), `results/<img>_final.csv`, `results/<img>_summary.json`.

## 5. Limitações e efeitos indesejados

- **Onde a sequência ajuda:** remove as partículas (18 → 5 componentes em `cena_dificil`) e fecha o furo, sem
  perda visível de contorno nos discos.
- **Onde não resolve:** os dois discos em contato continuam **um** componente (rótulo 3, caixa 188×103, área
  15 862). Contagem final = 5; contagem humana = 6. Pelo desenho da cena, o "pescoço" entre os discos tem cerca de
  50 px de largura; separá-los por erosão/abertura exigiria um elemento dessa ordem, o que destruiria outros objetos.
- **Onde prejudica:** *abertura agressiva* (elipse 95×95, `results/variants/open95_*`): fica com 3 componentes de 6
  e perde 15 674 px de primeiro plano (−32,9%) — objetos com diâmetro menor que o elemento desaparecem. *Elementos
  pequenos* (3×3/5×5, `results/variants/small3_5_*`): sobram 16 componentes brutos (14 após filtro), ou seja, o
  ruído passa. Figura 5 compara.
- **Mudança de contorno:** o fechamento suaviza reentrâncias (ver observação 3); um objeto com concavidade real
  pequena também seria preenchido.

![variantes](results/figures/fig_m2_2_variantes.png)
*Figura 5 — `cena_dificil`: sequência adotada × elementos pequenos × abertura agressiva.*

## 6. A contagem se aproxima da interpretação humana?

Em `cena_favoravel`, sim: 6 componentes finais = 6 discos que um observador contaria. Em `cena_dificil`, quase: 5
componentes contra 6 discos; a diferença é inteiramente o contato entre dois discos. A contagem de componentes não é
o número de objetos porque (i) objetos em contato ou sobrepostos viram um componente; (ii) objetos fragmentados viram
vários (ver a máscara `fixed`: 186–365 componentes); (iii) ruído pode ser contado como objeto, e o limiar de área é
uma escolha (20 px deixa 15 componentes, a morfologia deixa 5); (iv) objetos cortados pela borda contam como um
componente de área parcial. Separar contatos exigiria watershed ou análise de contornos (extensões opcionais, não
implementadas). Os "6 objetos reais" vêm da construção sintética (`tools/make_images.py`), não de contagem manual em
foto real.

## 7. Testes e reprodução

`ctest --test-dir build` (95 verificações) cobre os casos exigidos (diagonal 2/1, ruído + abertura, furo + fechamento,
máscara vazia, objeto na borda, `--connectivity` inválido, soma de áreas, reexecução das duas imagens). Para
regerar tudo: `./run_all.sh`.
