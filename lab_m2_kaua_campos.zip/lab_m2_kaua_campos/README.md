# pdi_lab — Processamento de Imagens 2026-02 · Laboratórios M2.1 e M2.2

Um único projeto C++17 + OpenCV com três operações por linha de comando:

| operação  | marco | função |
|-----------|-------|--------|
| `segment` | M2.1  | máscara binária por limiar `fixed`, `otsu`, `adaptive` ou `hsv` |
| `analyze` | M2.2  | rotulação 4/8, sequência morfológica, CSV, imagem de rótulos e resumo JSON |
| `overlay` | M2.1  | sobreposição máscara + imagem para localizar falsos positivos/negativos |

Relatório: [`REPORT.md`](REPORT.md) · Declaração de IA: [`AI_USAGE.md`](AI_USAGE.md) · Metadados: [`lab.json`](lab.json)

## Dependências

- Compilador C++17 (g++ ≥ 9, clang ≥ 10 ou MSVC 2019+), **CMake ≥ 3.16**.
- **OpenCV 4.x** (módulos `core`, `imgproc`, `imgcodecs`). Versão usada nos resultados: **OpenCV 4.6.0**
  (pacote `libopencv-dev` do Ubuntu 24.04, ligação C++ via CMake `find_package(OpenCV)`).
- Somente para as ferramentas auxiliares em `tools/` (geração das imagens sintéticas e das figuras do relatório,
  **não** fazem parte do `pdi_lab`): Python 3 + `numpy` + `opencv-python` (testado com `cv2` 4.13.0).

Instalação do OpenCV:

```bash
# Arch Linux
sudo pacman -S --needed base-devel cmake opencv
# Debian/Ubuntu
sudo apt install build-essential cmake libopencv-dev
# macOS (Homebrew)
brew install cmake opencv
# Windows: vcpkg  ->  vcpkg install opencv4   (e passe -DCMAKE_TOOLCHAIN_FILE=<vcpkg>/scripts/buildsystems/vcpkg.cmake)
```

## Compilar e testar

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
ctest --test-dir build --output-on-failure     # ou: ./build/pdi_tests
```

Os binários ficam em `build/` (pasta gerada, fora da entrega). Invocação do comando:

- Linux/macOS: `./build/pdi_lab ...`
- Windows (MSVC): `build\Release\pdi_lab.exe ...`  (ou `build\pdi_lab.exe` com geradores single-config)

Não há interface gráfica nem interação durante a execução; o processamento de uma máscara não depende de estado
de execuções anteriores. `--help` imprime todas as opções.

## Reproduzir todos os resultados

```bash
./run_all.sh                      # Linux/macOS/WSL/Git Bash; opcional: ./run_all.sh caminho/para/pdi_lab
python3 tools/make_figures.py     # (opcional) remonta as figuras de results/figures/
```

`run_all.sh` gera, a partir de `images/input/` (originais nunca alterados), tudo em `images/output/` e `results/`.
Reexecutar com os mesmos dados e parâmetros produz os mesmos arquivos.

As duas imagens de entrada são **sintéticas** e saem de `python3 tools/make_images.py` (semente fixa). Para usar fotos
próprias/fornecidas, coloque-as em `images/input/` com os mesmos nomes (ou ajuste `IMGS` em `run_all.sh`) e execute
os mesmos comandos; os parâmetros HSV/limiar precisarão ser reavaliados.

## M2.1 — `segment`

```bash
# Configuração 1: limiar fixo em cinza (pixel cinza > T => objeto = 255)
./build/pdi_lab --input images/input/cena_dificil.png --output images/output/cena_dificil_fixed.png \
  --operation segment --method fixed --threshold 120

# Configuração 2: intervalo HSV (escala OpenCV: H 0-179, S/V 0-255) com Gaussiana 5x5
./build/pdi_lab --input images/input/cena_dificil.png --output images/output/cena_dificil_mask.png \
  --operation segment --method hsv --hsv-low 5,100,40 --hsv-high 40,255,255 --blur 5

# Outras: Otsu e adaptativo (Gaussiano); --invert para objeto escuro
./build/pdi_lab --input images/input/cena_dificil.png --output images/output/cena_dificil_otsu.png \
  --operation segment --method otsu --blur 5
./build/pdi_lab --input images/input/cena_dificil.png --output images/output/cena_dificil_adaptive.png \
  --operation segment --method adaptive --blur 5 --block-size 101 --c -10

# Sobreposição para localizar erros (vermelho = máscara, verde = contorno)
./build/pdi_lab --input images/input/cena_dificil.png --mask images/output/cena_dificil_mask.png \
  --output images/output/cena_dificil_hsv_overlay.png --operation overlay
```

| opção | significado |
|-------|-------------|
| `--method fixed\|otsu\|adaptive\|hsv` | obrigatório |
| `--threshold 0..255` | `fixed`; padrão 120; regra `cinza > T` (pixel igual a T vira fundo) |
| `--invert` | objeto escuro (inverte a máscara resultante; vale para todos os métodos) |
| `--blur k` | pré-processamento: Gaussiana k×k (0 desliga; k ímpar ≥ 3) |
| `--block-size n`, `--c x` | `adaptive`: vizinhança ímpar ≥ 3 (padrão 51) e constante subtraída (padrão 5) |
| `--hsv-low H,S,V`, `--hsv-high H,S,V` | `hsv`; se H mínimo > H máximo, a faixa cruza o matiz 179→0 e é tratada como união |

A máscara é gravada **exatamente** em `--output` (somente formatos sem perdas: `.png`, `.bmp`, `.tif`): 1 canal,
mesma largura/altura da entrada, valores 0/255, objeto = 255. O programa confirma isso antes de gravar. Também é
gravado `<output sem extensão>.json` com método, pré-processamento, parâmetros, dimensões, nº de pixels de primeiro
plano e proporção; a mesma linha-resumo vai para a saída padrão.

## M2.2 — `analyze`

```bash
# Conectividade 8 (análise final), filtro de área 20 px, sequência morfológica de morph_sequence.txt
./build/pdi_lab --input images/output/cena_dificil_mask.png --output results/cena_dificil \
  --operation analyze --connectivity 8 --min-area 20 --morph-file morph_sequence.txt

# Conectividade 4, sequência passada na linha de comando
./build/pdi_lab --input images/output/cena_dificil_mask.png --output results/cena_dificil_c4 \
  --operation analyze --connectivity 4 --min-area 20 \
  --morph "open:ellipse:9:1;close:ellipse:11:1"
```

| opção | significado |
|-------|-------------|
| `--connectivity 4\|8` | conectividade da análise final (padrão **8**); as duas são sempre contadas no resumo |
| `--min-area n` | inteiro ≥ 0 (padrão 0 = sem filtro); componente `kept` se `área >= n` |
| `--morph "op:forma:tam:iter;..."` | `op` ∈ erode, dilate, open, close · `forma` ∈ rect, ellipse, cross · `tam` ímpar ≥ 1 · `iter` ≥ 1 |
| `--morph-file arq` | mesma sequência, uma operação por linha (`#` = comentário). Padrão se omitido: `open:ellipse:9:1;close:ellipse:11:1` |

A sequência exige ≥ 2 operações e ao menos uma abertura ou fechamento (erro, código 4, caso contrário). Nenhuma
edição de código é necessária para outro caso.

Com prefixo `P` (`--output P`), `analyze` grava:

| arquivo | conteúdo |
|---------|----------|
| `P_mask_initial.png` | cópia da máscara de entrada (objeto 255, fundo 0) |
| `P_stage1_open.png`, `P_stage2_close.png`, … | saída de cada estágio morfológico (`P_stage<N>_<op>.png`) |
| `P_mask_final.png` | máscara após a sequência |
| `P_initial.csv`, `P_final.csv` | `label,area,x,y,width,height,cx,cy,kept` (fundo excluído; `kept` = passou no filtro) |
| `P_initial_labels.png`, `P_labels.png` | rótulos coloridos + caixas (verde = mantido, vermelho/cinza = descartado) |
| `P_summary.json` | conectividade, `min_area`, sequência, contagens bruta/filtrada (inicial e final, em 4 e 8), áreas totais, verificação soma-das-áreas = pixels de primeiro plano |

## Erros e códigos de saída

`0` sucesso · `1` erro inesperado · `2` uso incorreto · `3` arquivo ausente/ilegível · `4` método/parâmetro inválido
(inclui `--connectivity` ≠ 4/8, formato de saída com perdas) · `5` máscara não binária / não 1 canal / dimensões
incompatíveis · `6` falha de gravação. A mensagem vai para `stderr`, iniciada por `erro:`.

## Testes (`tests/test_main.cpp`, 95 verificações)

- **M2.1:** limiar fixo em imagem sintética (pixels abaixo/igual/acima do limiar, com e sem `--invert`); máscaras
  binárias dos demais métodos; faixa HSV que cruza o matiz; leitura inexistente/ilegível, método desconhecido,
  limiar fora de faixa/não numérico, bloco par, saída `.jpg`, falha de gravação; dimensões, canal único e `{0,255}`.
- **M2.2:** dois pixels na diagonal (2 componentes em 4, 1 em 8); abertura remove ruído isolado; fechamento preenche
  furo de 1 px; máscara vazia (contagem 0); objeto no canto da imagem; filtro por área (bruto × filtrado);
  `--connectivity` inválido, `--min-area` negativo, sequência inválida, máscara não binária/3 canais; pipeline
  completo com todos os arquivos, cópia fiel da máscara inicial, soma das áreas = pixels de primeiro plano e
  reexecução idêntica; as duas imagens reais com as duas configurações (fixed, hsv) e conectividades 4 e 8.
- Um teste executa o binário como processo (`std::system`) e confere código 0 / ≠ 0 (somente Linux/macOS).

## Estrutura

```
README.md  REPORT.md  AI_USAGE.md  lab.json  CMakeLists.txt  run_all.sh  morph_sequence.txt
src/       common, segment, analyze, cli, main (C++17)
tests/     test_main.cpp
tools/     make_images.py, make_figures.py, summarize.py   (auxiliares, Python)
images/input/   originais (sintéticos)      images/output/   máscaras e sobreposições do M2.1
results/        saídas do M2.2, tabelas CSV do relatório e results/figures/
```

Não são entregues binários, `build/`, caches nem ambientes virtuais (ver `.gitignore`).
