#!/usr/bin/env python3
"""Imprime tabelas em Markdown a partir de results/*_summary.json (auxiliar do REPORT.md)."""
import csv, json, os
R = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results")
def J(n): return json.load(open(os.path.join(R, n)))
for img in ("cena_favoravel", "cena_dificil"):
    s, s4 = J(f"{img}_summary.json"), J(f"{img}_c4_summary.json")
    c = s["connectivity_comparison"]
    print(f"\n## {img}")
    print("conectividade (inicial): 4 ->", c["initial_4"]["raw_components"], " 8 ->", c["initial_8"]["raw_components"])
    print("conectividade (final):   4 ->", c["final_4"]["raw_components"], " 8 ->", c["final_8"]["raw_components"])
    for k in ("initial", "final"):
        v = s[k]; print(f"{k}: bruto={v['raw_components']} filtrado={v['kept_components']} area={v['foreground_area']} area_mantida={v['kept_area']}")
    print("pixels 1o plano:", s["foreground_pixels"], "| area_sum_check:", s["area_sum_check"])
    for st in s["morphology"]: print(" ", st["stage"], st["op"], st["shape"], st["ksize"], st["iterations"])
    for tag in ("initial", "final"):
        print(f" CSV {tag}:")
        for r in csv.DictReader(open(os.path.join(R, f"{img}_{tag}.csv"))): print("   ", dict(r))
for v in ("small3_5", "open95"):
    s = J(f"variants/{v}_summary.json")
    print("\nvariante", v, [m["op"] + str(m["ksize"]) for m in s["morphology"]], "inicial", s["initial"]["raw_components"], s["initial"]["kept_components"], "final", s["final"]["raw_components"], s["final"]["kept_components"], "fg", s["foreground_pixels"])
