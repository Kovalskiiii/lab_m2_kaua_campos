#!/usr/bin/env python3
"""Monta as figuras lado a lado do REPORT.md a partir de images/ e results/ (requer numpy e opencv-python).
Ferramenta auxiliar de documentação; não faz parte do pipeline pdi_lab."""
import os
import cv2
import numpy as np

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
OUT, RES, FIG = (os.path.join(ROOT, p) for p in ("images/output", "results", "results/figures"))
IN = os.path.join(ROOT, "images/input")
os.makedirs(FIG, exist_ok=True)
SCALE = 0.5


def load(path):
    img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    if img is None:
        raise SystemExit(f"arquivo ausente: {path} (rode ./run_all.sh antes)")
    if img.ndim == 2:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    return cv2.resize(img, None, fx=SCALE, fy=SCALE, interpolation=cv2.INTER_AREA)


def panel(path, caption):
    img = load(path)
    bar = np.full((22, img.shape[1], 3), 255, np.uint8)
    cv2.putText(bar, caption, (4, 16), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 0, 0), 1, cv2.LINE_AA)
    return cv2.copyMakeBorder(np.vstack([bar, img]), 0, 0, 0, 4, cv2.BORDER_CONSTANT, value=(255, 255, 255))


def grid(rows):
    w = max(sum(p.shape[1] for p in r) for r in rows)
    out = []
    for r in rows:
        row = np.hstack(r)
        out.append(cv2.copyMakeBorder(row, 0, 4, 0, w - row.shape[1], cv2.BORDER_CONSTANT, value=(255, 255, 255)))
    return np.vstack(out)


for img in ("cena_favoravel", "cena_dificil"):
    rows = [
        [panel(f"{IN}/{img}.png", "original"),
         panel(f"{OUT}/{img}_fixed.png", "fixed T=120"),
         panel(f"{OUT}/{img}_otsu.png", "otsu (blur 5)"),
         panel(f"{OUT}/{img}_adaptive.png", "adaptive 101, C=-10")],
        [panel(f"{OUT}/{img}_hsv.png", "hsv H5-40 S>=100 V>=40"),
         panel(f"{OUT}/{img}_fixed_overlay.png", "sobreposicao: fixed"),
         panel(f"{OUT}/{img}_hsv_overlay.png", "sobreposicao: hsv")],
    ]
    cv2.imwrite(f"{FIG}/fig_m2_1_{img}.png", grid(rows))
    cv2.imwrite(f"{FIG}/fig_m2_2_{img}.png", grid([[
        panel(f"{RES}/{img}_initial_labels.png", "inicial (rotulos, c=8)"),
        panel(f"{RES}/{img}_stage1_open.png", "etapa 1: abertura elipse 9"),
        panel(f"{RES}/{img}_stage2_close.png", "etapa 2: fechamento elipse 11"),
        panel(f"{RES}/{img}_labels.png", "final (rotulos, c=8)")]]))

cv2.imwrite(f"{FIG}/fig_m2_2_variantes.png", grid([[
    panel(f"{RES}/cena_dificil_labels.png", "adotada: open 9 / close 11"),
    panel(f"{RES}/variants/small3_5_labels.png", "elementos pequenos: open 3 / close 5"),
    panel(f"{RES}/variants/open95_labels.png", "abertura agressiva: open 95")]]))
print("figuras em", os.path.normpath(FIG))
