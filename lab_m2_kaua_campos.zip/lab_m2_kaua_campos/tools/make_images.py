#!/usr/bin/env python3
"""Gera as duas imagens SINTÉTICAS de entrada (semente fixa => reprodutível).

Uso: python3 tools/make_images.py   (requer numpy e opencv-python)
Ferramenta auxiliar: NÃO faz parte do pipeline pdi_lab. Para usar fotos reais,
basta colocar os arquivos em images/input/ e repetir os comandos do README.
"""
import os
import numpy as np
import cv2

W, H = 640, 480
OBJ = (60, 150, 235)   # BGR laranja (objeto de interesse)
BG = (45, 35, 25)      # BGR azul-escuro (fundo)
root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "images", "input")
os.makedirs(root, exist_ok=True)


def disc(img, c, r, col=OBJ):
    cv2.circle(img, c, r, col, -1, cv2.LINE_AA)


# --- Cena favorável: 6 discos bem separados, fundo uniforme, ruído leve -------------
rng = np.random.default_rng(42)
a = np.full((H, W, 3), BG, np.uint8)
for c, r in [((110, 110), 55), ((320, 100), 48), ((530, 120), 52),
             ((140, 330), 50), ((350, 340), 58), ((540, 350), 45)]:
    disc(a, c, r)
disc(a, (240, 230), 3)  # um pequeno ponto isolado
a = np.clip(a.astype(np.float32) + rng.normal(0, 3, a.shape), 0, 255).astype(np.uint8)
cv2.imwrite(os.path.join(root, "cena_favoravel.png"), a)

# --- Cena difícil: iluminação em gradiente, sombras, ruído, contato, furo, partículas ---
rng = np.random.default_rng(7)
b = np.full((H, W, 3), BG, np.uint8)
# sombras (elipses escuras deslocadas, desenhadas antes dos objetos)
for c, ax in [((135, 135), (60, 22)), ((545, 375), (55, 20))]:
    cv2.ellipse(b, c, ax, 0, 0, 360, (15, 12, 8), -1, cv2.LINE_AA)
disc(b, (110, 110), 52)                      # isolado
disc(b, (300, 120), 50)                      # par em contato
disc(b, (385, 120), 50)
disc(b, (520, 330), 55)                      # com furo pequeno
cv2.circle(b, (520, 330), 3, BG, -1, cv2.LINE_AA)
disc(b, (150, 350), 48)                      # perto do outro lado
disc(b, (620, 60), 45)                       # toca a borda direita
rng2 = np.random.default_rng(99)
for _ in range(14):                          # partículas pequenas (ruído)
    p = (int(rng2.integers(20, W - 20)), int(rng2.integers(200, H - 20)))
    disc(b, p, int(rng2.integers(1, 4)))
# gradiente de iluminação: esquerda escura (x0.45) -> direita clara (x1.9)
grad = np.linspace(0.45, 1.9, W, dtype=np.float32)[None, :, None]
b = np.clip(b.astype(np.float32) * grad, 0, 255)
b = np.clip(b + rng.normal(0, 6, b.shape), 0, 255).astype(np.uint8)
cv2.imwrite(os.path.join(root, "cena_dificil.png"), b)
print("imagens geradas em", os.path.normpath(root))
