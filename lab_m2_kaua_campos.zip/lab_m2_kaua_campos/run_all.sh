#!/usr/bin/env bash
# Executa M2.1 e M2.2 em todas as imagens de images/input.
# Compatível com MSYS2 UCRT64.

set -uo pipefail
cd "$(dirname "$0")" || exit 1

BIN="${1:-src/pdi_lab.exe}"
IN="images/input"
OUT="images/output"
RES="results"

HSV=(--hsv-low 5,100,40 --hsv-high 40,255,255 --blur 5)
MORPH=(--morph "open:ellipse:9:1;close:ellipse:11:1")

if [[ -f morph_sequence.txt ]]; then
    MORPH=(--morph-file morph_sequence.txt)
fi

if [[ ! -f "$BIN" ]]; then
    echo "ERRO: executável não encontrado: $BIN"
    echo "Informe o caminho correto como argumento."
    exit 1
fi

if [[ ! -d "$IN" ]]; then
    echo "ERRO: pasta não encontrada: $IN"
    exit 1
fi

# Descobre arquivos de imagem sem diferenciar maiúsculas.
shopt -s nullglob nocaseglob
IMAGENS=(
    "$IN"/*.png "$IN"/*.jpg "$IN"/*.jpeg
    "$IN"/*.bmp "$IN"/*.tif "$IN"/*.tiff
)

if (( ${#IMAGENS[@]} == 0 )); then
    echo "Nenhuma imagem encontrada em $IN"
    exit 1
fi

mkdir -p "$OUT" "$RES" "$RES/variants"

TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

TABLE="$RES/m2_1_proportions.csv"
SENS="$RES/m2_1_sensitivity_fixed.csv"
HUE="$RES/m2_1_sensitivity_hsv_hue.csv"
CNT="$RES/m2_1_components_by_config.csv"

echo "image,config,method,parameters,foreground_pixels,proportion" > "$TABLE"
echo "image,threshold,foreground_pixels,proportion" > "$SENS"
echo "image,hue_max,foreground_pixels,proportion" > "$HUE"
echo "image,config,components_c4,components_c8" > "$CNT"

sucessos=0
falhas=0

# Executa segmentação e registra as estatísticas.
seg() {
    local caminho="$1" nome="$2" cfg="$3" metodo="$4"
    shift 4

    local linha n p

    if linha=$("$BIN" --input "$caminho" \
        --output "$OUT/${nome}_${cfg}.png" \
        --operation segment --method "$metodo" "$@"); then

        n=$(sed -nE 's/.*foreground_pixels=([0-9]+).*/\1/p' <<< "$linha")
        p=$(sed -nE 's/.*proportion=([0-9.]+).*/\1/p' <<< "$linha")

        if [[ -z "$n" || -z "$p" ]]; then
            echo "ERRO: estatísticas não encontradas: $nome ($cfg)"
            ((falhas+=1))
            return 1
        fi

        printf '%s,%s,%s,"%s",%s,%s\n' \
            "$nome" "$cfg" "$metodo" "$*" "$n" "$p" >> "$TABLE"

        echo "$linha"
        ((sucessos+=1))
    else
        echo "Falha na segmentação: $nome ($cfg)"
        ((falhas+=1))
        return 1
    fi
}

# Executa análise de componentes.
analisar() {
    local mascara="$1" prefixo="$2" conectividade="$3" min_area="$4"

    if "$BIN" --input "$mascara" --output "$prefixo" \
        --operation analyze --connectivity "$conectividade" \
        --min-area "$min_area" "${MORPH[@]}"; then
        ((sucessos+=1))
    else
        echo "Falha na análise: $prefixo"
        ((falhas+=1))
        return 1
    fi
}

contar_componentes() {
    local arquivo="$1" conectividade="$2"

    sed -nE \
        "s/.*\"initial_${conectividade}\".*\"raw_components\": ([0-9]+).*/\1/p" \
        "$arquivo"
}

echo "=========================================="
echo " Testes PDI - MSYS2 UCRT64"
echo " Imagens encontradas: ${#IMAGENS[@]}"
echo " Executável: $BIN"
echo "=========================================="

for caminho in "${IMAGENS[@]}"; do
    arquivo="${caminho##*/}"
    nome="${arquivo%.*}"

    echo
    echo ">>> Processando: $arquivo"

    # M2.1: métodos de segmentação.
    seg "$caminho" "$nome" fixed fixed \
        --threshold 120 || true

    seg "$caminho" "$nome" otsu otsu \
        --blur 5 || true

    seg "$caminho" "$nome" adaptive adaptive \
        --blur 5 --block-size 101 --c -10 || true

    seg "$caminho" "$nome" hsv hsv \
        "${HSV[@]}" || true

    # Máscara de trabalho HSV.
    if "$BIN" --input "$caminho" \
        --output "$OUT/${nome}_mask.png" \
        --operation segment --method hsv "${HSV[@]}"; then
        ((sucessos+=1))
    else
        echo "Falha ao gerar máscara HSV: $nome"
        ((falhas+=1))
        continue
    fi

    # Sobreposições.
    for cfg in fixed hsv; do
        if [[ ! -f "$OUT/${nome}_${cfg}.png" ]]; then
            echo "Máscara ausente para overlay: $nome ($cfg)"
            ((falhas+=1))
            continue
        fi

        if "$BIN" --input "$caminho" \
            --mask "$OUT/${nome}_${cfg}.png" \
            --output "$OUT/${nome}_${cfg}_overlay.png" \
            --operation overlay; then
            ((sucessos+=1))
        else
            echo "Falha na sobreposição: $nome ($cfg)"
            ((falhas+=1))
        fi
    done

    # M2.2: conectividade 8 e comparação com 4.
    analisar "$OUT/${nome}_mask.png" "$RES/$nome" 8 20 || true
    analisar "$OUT/${nome}_mask.png" "$RES/${nome}_c4" 4 20 || true

    # Variantes morfológicas.
    for variante in open95 small3_5; do
        case "$variante" in
            open95)
                seq="open:ellipse:95:1;close:ellipse:11:1"
                ;;
            small3_5)
                seq="open:ellipse:3:1;close:ellipse:5:1"
                ;;
        esac

        if "$BIN" --input "$OUT/${nome}_mask.png" \
            --output "$RES/variants/${nome}_${variante}" \
            --operation analyze --connectivity 8 --min-area 20 \
            --morph "$seq"; then
            ((sucessos+=1))
        else
            echo "Falha na variante $variante: $nome"
            ((falhas+=1))
        fi
    done

    # Sensibilidade do limiar fixo.
    for t in 60 90 120 150 180; do
        if linha=$("$BIN" --input "$caminho" \
            --output "$TMP/test.png" --operation segment \
            --method fixed --threshold "$t"); then

            n=$(sed -nE 's/.*foreground_pixels=([0-9]+).*/\1/p' <<< "$linha")
            p=$(sed -nE 's/.*proportion=([0-9.]+).*/\1/p' <<< "$linha")
            echo "$nome,$t,$n,$p" >> "$SENS"
            ((sucessos+=1))
        else
            echo "Falha no limiar $t: $nome"
            ((falhas+=1))
        fi
    done

    # Sensibilidade do matiz HSV.
    for h in 20 25 30 35 40 60; do
        if linha=$("$BIN" --input "$caminho" \
            --output "$TMP/test.png" --operation segment \
            --method hsv --hsv-low 5,100,40 \
            --hsv-high "$h,255,255" --blur 5); then

            n=$(sed -nE 's/.*foreground_pixels=([0-9]+).*/\1/p' <<< "$linha")
            p=$(sed -nE 's/.*proportion=([0-9.]+).*/\1/p' <<< "$linha")
            echo "$nome,$h,$n,$p" >> "$HUE"
            ((sucessos+=1))
        else
            echo "Falha no HSV com matiz máximo $h: $nome"
            ((falhas+=1))
        fi
    done

    # Componentes por configuração de segmentação.
    for cfg in fixed otsu adaptive hsv; do
        mascara="$OUT/${nome}_${cfg}.png"
        prefixo="$TMP/${nome}_${cfg}"

        if [[ ! -f "$mascara" ]]; then
            echo "Máscara ausente para análise: $nome ($cfg)"
            echo "$nome,$cfg,NA,NA" >> "$CNT"
            ((falhas+=1))
            continue
        fi

        if "$BIN" --input "$mascara" \
            --output "$prefixo" --operation analyze --min-area 0 \
            "${MORPH[@]}" >/dev/null; then

            resumo="${prefixo}_summary.json"
            c4=$(contar_componentes "$resumo" 4)
            c8=$(contar_componentes "$resumo" 8)

            echo "$nome,$cfg,${c4:-NA},${c8:-NA}" >> "$CNT"
            ((sucessos+=1))
        else
            echo "Falha na contagem de componentes: $nome ($cfg)"
            echo "$nome,$cfg,NA,NA" >> "$CNT"
            ((falhas+=1))
        fi
    done
done

echo
echo "=========================================="
echo " Execução concluída"
echo " Imagens encontradas: ${#IMAGENS[@]}"
echo " Operações bem-sucedidas: $sucessos"
echo " Operações com falha: $falhas"
echo
echo "Máscaras e sobreposições: $OUT/"
echo "Relatórios e análises: $RES/"
echo "Tabelas CSV:"
echo "  $TABLE"
echo "  $SENS"
echo "  $HUE"
echo "  $CNT"
echo "=========================================="

if (( falhas > 0 )); then
    exit 1
fi
