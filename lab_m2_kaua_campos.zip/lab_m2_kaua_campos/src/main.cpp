#include <algorithm>
#include <cctype>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <locale>
#include <map>
#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

using namespace std;
namespace fs = filesystem;

namespace pdi {

enum ExitCode {
  EXIT_OK = 0,
  EXIT_GENERIC = 1,
  EXIT_USAGE = 2,
  EXIT_READ_ERROR = 3,
  EXIT_INVALID_PARAM = 4,
  EXIT_BAD_INPUT = 5,
  EXIT_WRITE_ERROR = 6
};

struct PdiError : runtime_error {
  int code;
  PdiError(int c, const string& msg) : runtime_error(msg), code(c) {}
};

cv::Mat readColorImage(const string& path);
cv::Mat readBinaryMask(const string& path);
void validateBinaryMask(const cv::Mat& m, const string& what);

void ensureParentDir(const string& path);
void writeLossless(const string& path, const cv::Mat& img);
void writeText(const string& path, const string& content);

string jsonEscape(const string& s);
string fmt(double v, int precision = 2);

}

namespace pdi {

struct SegmentParams {
  string method = "fixed";
  int threshold = 120;
  bool invert = false;
  int blur = 0;
  int blockSize = 51;
  double c = 5.0;
  cv::Vec3i hsvLow{0, 0, 0};
  cv::Vec3i hsvHigh{179, 255, 255};
};

struct SegmentResult {
  cv::Mat mask;
  double thresholdUsed = -1.0;
  long long fgPixels = 0;
  double fgProportion = 0.0;
};

SegmentResult segmentImage(const cv::Mat& bgr, const SegmentParams& p);

string segmentReportJson(const string& input, const string& output, const cv::Size& size, const SegmentParams& p, const SegmentResult& r);

cv::Mat makeOverlay(const cv::Mat& bgr, const cv::Mat& mask);

}

namespace pdi {

struct MorphOp {
  string op;
  string shape;
  int ksize = 3;
  int iterations = 1;
};

vector<MorphOp> parseMorph(const string& spec);

vector<MorphOp> readMorphFile(const string& path);

void validateSequence(const vector<MorphOp>& seq);
cv::Mat applyMorph(const cv::Mat& mask, const MorphOp& op);

extern const char* const kDefaultMorph;

struct Component {
  int label = 0;
  int area = 0;
  int x = 0, y = 0, width = 0, height = 0;
  double cx = 0.0, cy = 0.0;
  bool kept = true;
};

struct Labeling {
  cv::Mat labels;
  vector<Component> comps;
  int connectivity = 8;
  int minArea = 0;
  int rawCount = 0;
  int keptCount = 0;
  long long areaTotal = 0;
  long long areaKept = 0;
};

Labeling labelMask(const cv::Mat& mask, int connectivity, int minArea);
string componentsCsv(const Labeling& l);
cv::Mat drawLabeling(const cv::Mat& mask, const Labeling& l);

struct AnalyzeOptions {
  int connectivity = 8;
  int minArea = 0;
  vector<MorphOp> sequence;
  string morphSource = "default";
};

string runAnalyze(const string& inputPath, const string& prefix, const AnalyzeOptions& opt);

}

namespace pdi {

cv::Mat readColorImage(const string& path) {
  error_code ec;
  if (!fs::is_regular_file(path, ec))
    throw PdiError(EXIT_READ_ERROR, "arquivo não encontrado: " + path);
  cv::Mat img = cv::imread(path, cv::IMREAD_COLOR);
  if (img.empty())
    throw PdiError(EXIT_READ_ERROR, "arquivo ilegível ou formato não suportado: " + path);
  return img;
}

void validateBinaryMask(const cv::Mat& m, const string& what) {
  if (m.empty()) throw PdiError(EXIT_BAD_INPUT, what + " vazia (0x0)");
  if (m.type() != CV_8UC1)
    throw PdiError(EXIT_BAD_INPUT, what + " deve ter 1 canal de 8 bits (recebido: " +
                                       to_string(m.channels()) + " canal(is), profundidade " +
                                       to_string(m.depth()) + ")");
  const int total = m.rows * m.cols;
  const int zeros = cv::countNonZero(m == 0);
  const int fulls = cv::countNonZero(m == 255);
  if (zeros + fulls != total)
    throw PdiError(EXIT_BAD_INPUT, what + " não é binária: contém valores diferentes de 0 e 255");
}

cv::Mat readBinaryMask(const string& path) {
  error_code ec;
  if (!fs::is_regular_file(path, ec))
    throw PdiError(EXIT_READ_ERROR, "arquivo não encontrado: " + path);
  cv::Mat m = cv::imread(path, cv::IMREAD_UNCHANGED);
  if (m.empty())
    throw PdiError(EXIT_READ_ERROR, "arquivo ilegível ou formato não suportado: " + path);
  validateBinaryMask(m, "máscara '" + path + "'");
  return m;
}

void ensureParentDir(const string& path) {
  fs::path p(path);
  if (!p.has_parent_path()) return;
  error_code ec;
  fs::create_directories(p.parent_path(), ec);
  if (ec)
    throw PdiError(EXIT_WRITE_ERROR, "não foi possível criar a pasta " +
                                         p.parent_path().string() + ": " + ec.message());
}

void writeLossless(const string& path, const cv::Mat& img) {
  string ext = fs::path(path).extension().string();
  transform(ext.begin(), ext.end(), ext.begin(),
                 [](unsigned char c) { return static_cast<char>(tolower(c)); });
  if (ext != ".png" && ext != ".bmp" && ext != ".tif" && ext != ".tiff")
    throw PdiError(EXIT_INVALID_PARAM,
                   "formato de saída com perdas ou desconhecido ('" + ext + "'); use .png");
  ensureParentDir(path);
  bool ok = false;
  try {
    ok = cv::imwrite(path, img);
  } catch (const cv::Exception& e) {
    throw PdiError(EXIT_WRITE_ERROR, "falha ao gravar " + path + ": " + e.what());
  }
  if (!ok) throw PdiError(EXIT_WRITE_ERROR, "falha ao gravar " + path);
}

void writeText(const string& path, const string& content) {
  ensureParentDir(path);
  ofstream f(path, ios::binary);
  if (!f) throw PdiError(EXIT_WRITE_ERROR, "falha ao abrir para escrita: " + path);
  f << content;
  f.close();
  if (!f) throw PdiError(EXIT_WRITE_ERROR, "falha ao gravar " + path);
}

string jsonEscape(const string& s) {
  string o;
  for (unsigned char c : s) {
    switch (c) {
      case '"': o += "\\\""; break;
      case '\\': o += "\\\\"; break;
      case '\n': o += "\\n"; break;
      case '\t': o += "\\t"; break;
      default: o += static_cast<char>(c);
    }
  }
  return o;
}

string fmt(double v, int precision) {
  ostringstream os;
  os.imbue(locale::classic());
  os << fixed << setprecision(precision) << v;
  return os.str();
}

}

namespace pdi {

namespace {

void checkRange(const char* name, int v, int lo, int hi) {
  if (v < lo || v > hi)
    throw PdiError(EXIT_INVALID_PARAM, string(name) + " fora do intervalo [" + to_string(lo) + "," + to_string(hi) + "]: " + to_string(v));
}

void validate(const SegmentParams& p) {
  if (p.method != "fixed" && p.method != "otsu" && p.method != "adaptive" && p.method != "hsv")
    throw PdiError(EXIT_INVALID_PARAM,
                   "método desconhecido: '" + p.method + "' (use fixed, otsu, adaptive ou hsv)");
  if (p.blur != 0 && (p.blur < 3 || p.blur % 2 == 0))
    throw PdiError(EXIT_INVALID_PARAM, "--blur deve ser 0 ou ímpar >= 3");
  if (p.method == "fixed") checkRange("--threshold", p.threshold, 0, 255);
  if (p.method == "adaptive") {
    if (p.blockSize < 3 || p.blockSize % 2 == 0)
      throw PdiError(EXIT_INVALID_PARAM, "--block-size deve ser ímpar >= 3");
  }
  if (p.method == "hsv") {
    checkRange("H mínimo", p.hsvLow[0], 0, 179);
    checkRange("H máximo", p.hsvHigh[0], 0, 179);
    checkRange("S mínimo", p.hsvLow[1], 0, 255);
    checkRange("S máximo", p.hsvHigh[1], 0, 255);
    checkRange("V mínimo", p.hsvLow[2], 0, 255);
    checkRange("V máximo", p.hsvHigh[2], 0, 255);
    if (p.hsvLow[1] > p.hsvHigh[1] || p.hsvLow[2] > p.hsvHigh[2])
      throw PdiError(EXIT_INVALID_PARAM, "intervalo HSV inválido: mínimo > máximo em S ou V");

  }
}

}

SegmentResult segmentImage(const cv::Mat& bgr, const SegmentParams& p) {
  validate(p);
  if (bgr.empty() || bgr.type() != CV_8UC3)
    throw PdiError(EXIT_BAD_INPUT, "imagem de entrada deve ser BGR de 8 bits");

  cv::Mat src = bgr;
  if (p.blur > 0) {
    cv::Mat tmp;
    cv::GaussianBlur(bgr, tmp, cv::Size(p.blur, p.blur), 0);
    src = tmp;
  }

  SegmentResult r;
  const int bt = p.invert ? cv::THRESH_BINARY_INV : cv::THRESH_BINARY;

  if (p.method == "hsv") {
    cv::Mat hsv;
    cv::cvtColor(src, hsv, cv::COLOR_BGR2HSV);
    const cv::Vec3i lo = p.hsvLow, hi = p.hsvHigh;
    if (lo[0] <= hi[0]) {
      cv::inRange(hsv, cv::Scalar(lo[0], lo[1], lo[2]), cv::Scalar(hi[0], hi[1], hi[2]), r.mask);
    } else {
      cv::Mat a, b;
      cv::inRange(hsv, cv::Scalar(lo[0], lo[1], lo[2]), cv::Scalar(179, hi[1], hi[2]), a);
      cv::inRange(hsv, cv::Scalar(0, lo[1], lo[2]), cv::Scalar(hi[0], hi[1], hi[2]), b);
      cv::bitwise_or(a, b, r.mask);
    }
    if (p.invert) cv::bitwise_not(r.mask, r.mask);
  } else {
    cv::Mat gray;
    cv::cvtColor(src, gray, cv::COLOR_BGR2GRAY);
    if (p.method == "fixed") {
      r.thresholdUsed = cv::threshold(gray, r.mask, p.threshold, 255, bt);
    } else if (p.method == "otsu") {
      r.thresholdUsed = cv::threshold(gray, r.mask, 0, 255, bt | cv::THRESH_OTSU);
    } else {
      cv::adaptiveThreshold(gray, r.mask, 255, cv::ADAPTIVE_THRESH_GAUSSIAN_C, bt, p.blockSize,
                            p.c);
    }
  }

  validateBinaryMask(r.mask, "máscara gerada");
  r.fgPixels = cv::countNonZero(r.mask);
  r.fgProportion = static_cast<double>(r.fgPixels) / (static_cast<double>(r.mask.total()));
  return r;
}

string segmentReportJson(const string& input, const string& output, const cv::Size& size, const SegmentParams& p, const SegmentResult& r) {
  ostringstream o;
  o << "{\n";
  o << "  \"schema_version\": 1,\n";
  o << "  \"operation\": \"segment\",\n";
  o << "  \"input\": \"" << jsonEscape(input) << "\",\n";
  o << "  \"output\": \"" << jsonEscape(output) << "\",\n";
  o << "  \"image\": {\"width\": " << size.width << ", \"height\": " << size.height << "},\n";
  o << "  \"method\": \"" << p.method << "\",\n";
  o << "  \"preprocessing\": {\"gaussian_blur_ksize\": " << p.blur << "},\n";
  o << "  \"invert\": " << (p.invert ? "true" : "false") << ",\n";
  o << "  \"parameters\": {";
  if (p.method == "fixed") {
    o << "\"threshold\": " << p.threshold << ", \"rule\": \"gray > threshold => 255\"";
  } else if (p.method == "otsu") {
    o << "\"threshold_computed\": " << fmt(r.thresholdUsed, 0);
  } else if (p.method == "adaptive") {
    o << "\"mode\": \"gaussian\", \"block_size\": " << p.blockSize << ", \"c\": " << fmt(p.c, 2);
  } else {
    o << "\"hsv_low\": [" << p.hsvLow[0] << ", " << p.hsvLow[1] << ", " << p.hsvLow[2]
      << "], \"hsv_high\": [" << p.hsvHigh[0] << ", " << p.hsvHigh[1] << ", " << p.hsvHigh[2]
      << "], \"hue_range\": \"OpenCV 0-179\", \"hue_wraps\": "
      << (p.hsvLow[0] > p.hsvHigh[0] ? "true" : "false");
  }
  o << "},\n";
  o << "  \"foreground_pixels\": " << r.fgPixels << ",\n";
  o << "  \"foreground_proportion\": " << fmt(r.fgProportion, 6) << ",\n";
  o << "  \"binary_check\": {\"channels\": 1, \"values\": [0, 255], \"passed\": true}\n";
  o << "}\n";
  return o.str();
}

cv::Mat makeOverlay(const cv::Mat& bgr, const cv::Mat& mask) {
  if (bgr.size() != mask.size())
    throw PdiError(EXIT_BAD_INPUT, "imagem e máscara com dimensões diferentes");
  validateBinaryMask(mask, "máscara");
  cv::Mat red(bgr.size(), CV_8UC3, cv::Scalar(0, 0, 255)), blended, out = bgr.clone();
  cv::addWeighted(bgr, 0.55, red, 0.45, 0.0, blended);
  blended.copyTo(out, mask);
  vector<vector<cv::Point>> contours;
  cv::findContours(mask.clone(), contours, cv::RETR_LIST, cv::CHAIN_APPROX_NONE);
  cv::drawContours(out, contours, -1, cv::Scalar(0, 255, 0), 1, cv::LINE_8);
  return out;
}

}

namespace pdi {

const char* const kDefaultMorph = "open:ellipse:9:1;close:ellipse:11:1";

namespace {

string trim(const string& s) {
  size_t a = s.find_first_not_of(" \t\r\n");
  if (a == string::npos) return "";
  size_t b = s.find_last_not_of(" \t\r\n");
  return s.substr(a, b - a + 1);
}

vector<string> split(const string& s, char sep) {
  vector<string> out;
  string cur;
  istringstream is(s);
  while (getline(is, cur, sep)) out.push_back(cur);
  return out;
}

int toInt(const string& s, const string& what) {
  size_t pos = 0;
  int v = 0;
  try {
    v = stoi(s, &pos);
  } catch (...) {
    throw PdiError(EXIT_INVALID_PARAM, "valor inteiro inválido em " + what + ": '" + s + "'");
  }
  if (pos != s.size())
    throw PdiError(EXIT_INVALID_PARAM, "valor inteiro inválido em " + what + ": '" + s + "'");
  return v;
}

const char* kShapeNames[] = {"rect", "ellipse", "cross"};

string morphJson(const MorphOp& m, int stage, const string& file) {
  ostringstream o;
  o << "{\"stage\": " << stage << ", \"op\": \"" << m.op << "\", \"shape\": \"" << m.shape
    << "\", \"ksize\": " << m.ksize << ", \"iterations\": " << m.iterations << ", \"output\": \""
    << jsonEscape(file) << "\"}";
  return o.str();
}

string labelingJson(const Labeling& l) {
  ostringstream o;
  o << "{\"connectivity\": " << l.connectivity << ", \"min_area\": " << l.minArea
    << ", \"raw_components\": " << l.rawCount << ", \"kept_components\": " << l.keptCount
    << ", \"foreground_area\": " << l.areaTotal << ", \"kept_area\": " << l.areaKept << "}";
  return o.str();
}

}

vector<MorphOp> parseMorph(const string& spec) {
  vector<MorphOp> seq;
  for (const string& raw : split(spec, ';')) {
    const string tok = trim(raw);
    if (tok.empty()) continue;
    const auto f = split(tok, ':');
    if (f.size() != 4)
      throw PdiError(EXIT_INVALID_PARAM,
                     "operação morfológica inválida '" + tok + "' (use op:forma:tamanho:iteracoes)");
    MorphOp m;
    m.op = trim(f[0]);
    m.shape = trim(f[1]);
    m.ksize = toInt(trim(f[2]), "tamanho do elemento estruturante");
    m.iterations = toInt(trim(f[3]), "iterações");
    if (m.op != "erode" && m.op != "dilate" && m.op != "open" && m.op != "close")
      throw PdiError(EXIT_INVALID_PARAM,
                     "operação morfológica desconhecida: '" + m.op + "' (erode, dilate, open, close)");
    if (find(begin(kShapeNames), end(kShapeNames), m.shape) == end(kShapeNames))
      throw PdiError(EXIT_INVALID_PARAM,
                     "forma de elemento estruturante desconhecida: '" + m.shape +
                         "' (rect, ellipse, cross)");
    if (m.ksize < 1 || m.ksize % 2 == 0)
      throw PdiError(EXIT_INVALID_PARAM, "tamanho do elemento estruturante deve ser ímpar >= 1");
    if (m.iterations < 1)
      throw PdiError(EXIT_INVALID_PARAM, "número de iterações deve ser >= 1");
    seq.push_back(m);
  }
  return seq;
}

vector<MorphOp> readMorphFile(const string& path) {
  ifstream f(path);
  if (!f) throw PdiError(EXIT_READ_ERROR, "arquivo de configuração morfológica não encontrado: " + path);
  string line, joined;
  while (getline(f, line)) {
    const size_t h = line.find('#');
    if (h != string::npos) line = line.substr(0, h);
    line = trim(line);
    if (!line.empty()) joined += line + ";";
  }
  return parseMorph(joined);
}

void validateSequence(const vector<MorphOp>& seq) {
  if (seq.size() < 2)
    throw PdiError(EXIT_INVALID_PARAM, "a sequência morfológica precisa de pelo menos 2 operações");
  const bool hasOC = any_of(seq.begin(), seq.end(), [](const MorphOp& m) {
    return m.op == "open" || m.op == "close";
  });
  if (!hasOC)
    throw PdiError(EXIT_INVALID_PARAM, "a sequência deve conter ao menos uma abertura ou fechamento");
}

cv::Mat applyMorph(const cv::Mat& mask, const MorphOp& op) {
  int shape = cv::MORPH_RECT;
  if (op.shape == "ellipse") shape = cv::MORPH_ELLIPSE;
  else if (op.shape == "cross") shape = cv::MORPH_CROSS;
  int type = cv::MORPH_OPEN;
  if (op.op == "erode") type = cv::MORPH_ERODE;
  else if (op.op == "dilate") type = cv::MORPH_DILATE;
  else if (op.op == "close") type = cv::MORPH_CLOSE;
  const cv::Mat k = cv::getStructuringElement(shape, cv::Size(op.ksize, op.ksize));
  cv::Mat out;
  cv::morphologyEx(mask, out, type, k, cv::Point(-1, -1), op.iterations);
  return out;
}

Labeling labelMask(const cv::Mat& mask, int connectivity, int minArea) {
  if (connectivity != 4 && connectivity != 8)
    throw PdiError(EXIT_INVALID_PARAM,
                   "--connectivity deve ser 4 ou 8 (recebido: " + to_string(connectivity) + ")");
  if (minArea < 0) throw PdiError(EXIT_INVALID_PARAM, "--min-area deve ser inteiro >= 0");
  validateBinaryMask(mask, "máscara");

  Labeling r;
  r.connectivity = connectivity;
  r.minArea = minArea;
  cv::Mat stats, centroids;
  const int n = cv::connectedComponentsWithStats(mask, r.labels, stats, centroids, connectivity, CV_32S);
  for (int i = 1; i < n; ++i) {
    Component c;
    c.label = i;
    c.area = stats.at<int>(i, cv::CC_STAT_AREA);
    c.x = stats.at<int>(i, cv::CC_STAT_LEFT);
    c.y = stats.at<int>(i, cv::CC_STAT_TOP);
    c.width = stats.at<int>(i, cv::CC_STAT_WIDTH);
    c.height = stats.at<int>(i, cv::CC_STAT_HEIGHT);
    c.cx = centroids.at<double>(i, 0);
    c.cy = centroids.at<double>(i, 1);
    c.kept = c.area >= minArea;
    r.areaTotal += c.area;
    if (c.kept) {
      r.keptCount++;
      r.areaKept += c.area;
    }
    r.comps.push_back(c);
  }
  r.rawCount = static_cast<int>(r.comps.size());
  return r;
}

string componentsCsv(const Labeling& l) {
  ostringstream o;
  o << "label,area,x,y,width,height,cx,cy,kept\n";
  for (const Component& c : l.comps)
    o << c.label << ',' << c.area << ',' << c.x << ',' << c.y << ',' << c.width << ',' << c.height
      << ',' << fmt(c.cx) << ',' << fmt(c.cy) << ',' << (c.kept ? "true" : "false") << '\n';
  return o.str();
}

cv::Mat drawLabeling(const cv::Mat& mask, const Labeling& l) {
  static const cv::Vec3b palette[] = {{230, 159, 0},  {86, 180, 233}, {0, 158, 115}, {240, 228, 66},
                                      {0, 114, 178},  {213, 94, 0},   {204, 121, 167}, {180, 105, 255}};
  vector<cv::Vec3b> lut(l.comps.size() + 1, cv::Vec3b(0, 0, 0));
  for (const Component& c : l.comps)
    lut[c.label] = c.kept ? palette[c.label % 8] : cv::Vec3b(110, 110, 110);
  cv::Mat canvas(mask.size(), CV_8UC3, cv::Scalar(0, 0, 0));
  for (int y = 0; y < mask.rows; ++y) {
    const int* lp = l.labels.ptr<int>(y);
    cv::Vec3b* cp = canvas.ptr<cv::Vec3b>(y);
    for (int x = 0; x < mask.cols; ++x)
      if (lp[x] > 0) cp[x] = lut[lp[x]];
  }
  for (const Component& c : l.comps) {
    const cv::Scalar col = c.kept ? cv::Scalar(0, 255, 0) : cv::Scalar(0, 0, 255);
    cv::rectangle(canvas, cv::Rect(c.x, c.y, c.width, c.height), col, 1);
    cv::putText(canvas, to_string(c.label), cv::Point(c.x, max(c.y - 3, 10)),
                cv::FONT_HERSHEY_SIMPLEX, 0.4, cv::Scalar(255, 255, 255), 1, cv::LINE_AA);
  }
  return canvas;
}

string runAnalyze(const string& inputPath, const string& prefix,
                       const AnalyzeOptions& optIn) {
  AnalyzeOptions opt = optIn;
  if (opt.sequence.empty()) {
    opt.sequence = parseMorph(kDefaultMorph);
    opt.morphSource = "default";
  }
  validateSequence(opt.sequence);

  if (opt.connectivity != 4 && opt.connectivity != 8)
    throw PdiError(EXIT_INVALID_PARAM, "--connectivity deve ser 4 ou 8");
  if (opt.minArea < 0) throw PdiError(EXIT_INVALID_PARAM, "--min-area deve ser inteiro >= 0");

  const cv::Mat initial = readBinaryMask(inputPath);
  const long long fgInitial = cv::countNonZero(initial);

  writeLossless(prefix + "_mask_initial.png", initial);
  const Labeling i4 = labelMask(initial, 4, opt.minArea);
  const Labeling i8 = labelMask(initial, 8, opt.minArea);
  const Labeling& initialSel = opt.connectivity == 4 ? i4 : i8;
  if (initialSel.areaTotal != fgInitial)
    throw PdiError(EXIT_GENERIC, "inconsistência: soma das áreas != pixels de primeiro plano");
  writeText(prefix + "_initial.csv", componentsCsv(initialSel));
  writeLossless(prefix + "_initial_labels.png", drawLabeling(initial, initialSel));

  cv::Mat cur = initial;
  vector<string> stageJson;
  int stage = 0;
  for (const MorphOp& m : opt.sequence) {
    cur = applyMorph(cur, m);
    ++stage;
    const string file = prefix + "_stage" + to_string(stage) + "_" + m.op + ".png";
    writeLossless(file, cur);
    stageJson.push_back(morphJson(m, stage, file));
  }
  validateBinaryMask(cur, "máscara final");
  writeLossless(prefix + "_mask_final.png", cur);

  const long long fgFinal = cv::countNonZero(cur);
  const Labeling f4 = labelMask(cur, 4, opt.minArea);
  const Labeling f8 = labelMask(cur, 8, opt.minArea);
  const Labeling& finalSel = opt.connectivity == 4 ? f4 : f8;
  if (finalSel.areaTotal != fgFinal)
    throw PdiError(EXIT_GENERIC, "inconsistência: soma das áreas finais != pixels de primeiro plano");
  writeText(prefix + "_final.csv", componentsCsv(finalSel));
  writeLossless(prefix + "_labels.png", drawLabeling(cur, finalSel));

  ostringstream o;
  o << "{\n";
  o << "  \"schema_version\": 1,\n";
  o << "  \"operation\": \"analyze\",\n";
  o << "  \"input\": \"" << jsonEscape(inputPath) << "\",\n";
  o << "  \"prefix\": \"" << jsonEscape(prefix) << "\",\n";
  o << "  \"image\": {\"width\": " << initial.cols << ", \"height\": " << initial.rows << "},\n";
  o << "  \"mask_convention\": {\"object\": 255, \"background\": 0},\n";
  o << "  \"connectivity\": " << opt.connectivity << ",\n";
  o << "  \"min_area\": " << opt.minArea << ",\n";
  o << "  \"filter_rule\": \"componente mantido se area >= min_area; fundo (rotulo 0) nunca e contado\",\n";
  o << "  \"morphology_source\": \"" << jsonEscape(opt.morphSource) << "\",\n";
  o << "  \"morphology\": [\n    ";
  for (size_t i = 0; i < stageJson.size(); ++i) o << stageJson[i] << (i + 1 < stageJson.size() ? ",\n    " : "\n");
  o << "  ],\n";
  o << "  \"initial\": " << labelingJson(initialSel) << ",\n";
  o << "  \"final\": " << labelingJson(finalSel) << ",\n";
  o << "  \"connectivity_comparison\": {\n";
  o << "    \"initial_4\": " << labelingJson(i4) << ",\n";
  o << "    \"initial_8\": " << labelingJson(i8) << ",\n";
  o << "    \"final_4\": " << labelingJson(f4) << ",\n";
  o << "    \"final_8\": " << labelingJson(f8) << "\n  },\n";
  o << "  \"foreground_pixels\": {\"initial\": " << fgInitial << ", \"final\": " << fgFinal
    << ", \"delta\": " << (fgFinal - fgInitial) << "},\n";
  o << "  \"area_sum_check\": {\"initial\": " << (initialSel.areaTotal == fgInitial ? "true" : "false")
    << ", \"final\": " << (finalSel.areaTotal == fgFinal ? "true" : "false") << "},\n";
  o << "  \"outputs\": {\"mask_initial\": \"" << jsonEscape(prefix) << "_mask_initial.png\", "
    << "\"mask_final\": \"" << jsonEscape(prefix) << "_mask_final.png\", "
    << "\"initial_csv\": \"" << jsonEscape(prefix) << "_initial.csv\", "
    << "\"final_csv\": \"" << jsonEscape(prefix) << "_final.csv\", "
    << "\"initial_labels\": \"" << jsonEscape(prefix) << "_initial_labels.png\", "
    << "\"final_labels\": \"" << jsonEscape(prefix) << "_labels.png\"}\n";
  o << "}\n";
  const string summary = o.str();
  writeText(prefix + "_summary.json", summary);
  return summary;
}

}

namespace pdi {

int runCli(int argc, char** argv);

namespace {

const set<string> kValueOpts = {"input", "output", "operation", "method", "threshold", "blur", "block-size", "c", "hsv-low", "hsv-high", "connectivity", "min-area", "morph", "morph-file", "mask"};
const set<string> kFlagOpts = {"invert", "help"};

using Args = map<string, string>;

Args parseArgs(int argc, char** argv) {
  Args a;
  for (int i = 1; i < argc; ++i) {
    string t = argv[i];
    if (t.rfind("--", 0) != 0) throw PdiError(EXIT_USAGE, "argumento inesperado: '" + t + "'");
    const string key = t.substr(2);
    if (kFlagOpts.count(key)) {
      a[key] = "1";
    } else if (kValueOpts.count(key)) {
      if (i + 1 >= argc) throw PdiError(EXIT_USAGE, "faltou o valor de --" + key);
      a[key] = argv[++i];
    } else {
      throw PdiError(EXIT_USAGE, "opção desconhecida: --" + key);
    }
  }
  return a;
}

int parseInt(const string& name, const string& s) {
  size_t pos = 0;
  int v = 0;
  try {
    v = stoi(s, &pos);
  } catch (...) {
    pos = 0;
  }
  if (pos == 0 || pos != s.size())
    throw PdiError(EXIT_INVALID_PARAM, "valor inválido para --" + name + ": '" + s + "' (inteiro esperado)");
  return v;
}

double toDouble(const string& name, const string& s) {
  size_t pos = 0;
  double v = 0;
  try {
    v = stod(s, &pos);
  } catch (...) {
    pos = 0;
  }
  if (pos == 0 || pos != s.size())
    throw PdiError(EXIT_INVALID_PARAM, "valor inválido para --" + name + ": '" + s + "' (número esperado)");
  return v;
}

cv::Vec3i toTriple(const string& name, const string& s) {
  cv::Vec3i v;
  size_t start = 0;
  for (int k = 0; k < 3; ++k) {
    const size_t comma = s.find(',', start);
    const bool last = (k == 2);
    if ((comma == string::npos) != last)
      throw PdiError(EXIT_INVALID_PARAM, "--" + name + " deve ter o formato H,S,V (ex.: 5,100,50)");
    v[k] = parseInt(name, s.substr(start, last ? string::npos : comma - start));
    start = comma + 1;
  }
  return v;
}

string need(const Args& a, const string& key) {
  auto it = a.find(key);
  if (it == a.end()) throw PdiError(EXIT_USAGE, "faltou --" + key + " (veja --help)");
  return it->second;
}

string withJsonExt(const string& path) {
  return fs::path(path).replace_extension(".json").string();
}

int doSegment(const Args& a) {
  const string in = need(a, "input"), out = need(a, "output");
  SegmentParams p;
  p.method = need(a, "method");
  if (a.count("threshold")) p.threshold = parseInt("threshold", a.at("threshold"));
  p.invert = a.count("invert") > 0;
  if (a.count("blur")) p.blur = parseInt("blur", a.at("blur"));
  if (a.count("block-size")) p.blockSize = parseInt("block-size", a.at("block-size"));
  if (a.count("c")) p.c = toDouble("c", a.at("c"));
  if (a.count("hsv-low")) p.hsvLow = toTriple("hsv-low", a.at("hsv-low"));
  if (a.count("hsv-high")) p.hsvHigh = toTriple("hsv-high", a.at("hsv-high"));

  const cv::Mat img = readColorImage(in);
  const SegmentResult r = segmentImage(img, p);
  if (r.mask.size() != img.size())
    throw PdiError(EXIT_BAD_INPUT, "máscara com dimensões diferentes da entrada");
  validateBinaryMask(r.mask, "máscara final");
  writeLossless(out, r.mask);
  writeText(withJsonExt(out), segmentReportJson(in, out, img.size(), p, r));
  cout << "segment: method=" << p.method << " foreground_pixels=" << r.fgPixels
            << " proportion=" << fmt(r.fgProportion, 6) << " output=" << out << "\n";
  return EXIT_OK;
}

int doAnalyze(const Args& a) {
  const string in = need(a, "input"), prefix = need(a, "output");
  AnalyzeOptions opt;
  if (a.count("connectivity")) opt.connectivity = parseInt("connectivity", a.at("connectivity"));
  if (a.count("min-area")) opt.minArea = parseInt("min-area", a.at("min-area"));
  if (a.count("morph") && a.count("morph-file"))
    throw PdiError(EXIT_USAGE, "use apenas um entre --morph e --morph-file");
  if (a.count("morph")) {
    opt.sequence = parseMorph(a.at("morph"));
    opt.morphSource = "--morph";
  } else if (a.count("morph-file")) {
    opt.sequence = readMorphFile(a.at("morph-file"));
    opt.morphSource = "--morph-file " + a.at("morph-file");
  }
  runAnalyze(in, prefix, opt);

  const Labeling i = labelMask(readBinaryMask(prefix + "_mask_initial.png"), opt.connectivity, opt.minArea);
  const Labeling f = labelMask(readBinaryMask(prefix + "_mask_final.png"), opt.connectivity, opt.minArea);
  cout << "analyze: connectivity=" << opt.connectivity << " min_area=" << opt.minArea
            << " initial(raw=" << i.rawCount << ", kept=" << i.keptCount << ")"
            << " final(raw=" << f.rawCount << ", kept=" << f.keptCount << ")"
            << " summary=" << prefix << "_summary.json\n";
  return EXIT_OK;
}

int doOverlay(const Args& a) {
  const string in = need(a, "input"), out = need(a, "output"), mask = need(a, "mask");
  const cv::Mat img = readColorImage(in);
  const cv::Mat m = readBinaryMask(mask);
  writeLossless(out, makeOverlay(img, m));
  cout << "overlay: output=" << out << "\n";
  return EXIT_OK;
}

}

int runCli(int argc, char** argv) {
  try {
    const Args a = parseArgs(argc, argv);
    const string op = need(a, "operation");
    if (op == "segment") return doSegment(a);
    if (op == "analyze") return doAnalyze(a);
    if (op == "overlay") return doOverlay(a);
    throw PdiError(EXIT_INVALID_PARAM, "operação desconhecida: '" + op + "' (segment, analyze, overlay)");
  } catch (const PdiError& e) {
    cerr << "erro: " << e.what() << "\n";
    return e.code;
  } catch (const cv::Exception& e) {
    cerr << "erro (OpenCV): " << e.what() << "\n";
    return EXIT_GENERIC;
  } catch (const exception& e) {
    cerr << "erro inesperado: " << e.what() << "\n";
    return EXIT_GENERIC;
  }
}

}

int main(int argc, char** argv) { return pdi::runCli(argc, argv); }