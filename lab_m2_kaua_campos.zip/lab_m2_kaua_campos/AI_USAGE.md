# AI_USAGE — Declaração de uso de IA (M2.1 e M2.2)

**Ferramenta:** Claude (Anthropic), via chat, em outubro de 2026.

## O que a IA fez
- escreveu o código do arquivo `run_all.sh`, para realização de testes de forma simples e automatizada
- Auxiliou nos testes do opencv


